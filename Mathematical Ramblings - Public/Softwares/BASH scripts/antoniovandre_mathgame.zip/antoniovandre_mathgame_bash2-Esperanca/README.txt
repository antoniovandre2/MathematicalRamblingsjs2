Projeto Mathematical Ramblings (mathematicalramblings.blogspot.com).
____________________

Linux / Android version:

Run the software with the command "bash antoniovandre_mathgame".
_____

If your environment is not capable of producing sounds, run with "bash antoniovandre_mathgame_nosound".

If you are not a Linux or Android user, you can install a BASH shell on your operating system.

The processing of the statistics can be time consuming, so you can play with the command "bash antoniovandre_mathgame ne", where only the log file will be saved, and, when not using the device, execute "bash antoniovandre_mathgame oe" to only process the statistics.

There are many other options avaliable when editing fonts.
_____

The shell can make mistakes, in which case I am exempt from liability.
_____

Use and sharing license: Attribution-Non-Commercial-Share-Equal (CC BY-NC-SA).
